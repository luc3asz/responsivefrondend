const MyModule = {
  check() {
    console.log('Yaj! Modules are working!');
  }
}

export default MyModule;
