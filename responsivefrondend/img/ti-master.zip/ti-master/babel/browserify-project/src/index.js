import MyModule from './app';

MyModule.check();
