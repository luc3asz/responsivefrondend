# Oh shit, git!

* [Oh shit, git!](http://ohshitgit.com)

## Przydatne polecenia

```sh
git show master:README.md
git show geojson:README.md  # cat README.md from geojson branch

git diff geojson  # diff CURRENT_BRANCH geojson
```
